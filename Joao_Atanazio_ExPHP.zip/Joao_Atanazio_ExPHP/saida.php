<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    print "teste<br>";
    print "Olá, Mundo<br>\n";
    print "Escape 'chars' são os MESMOS como em C<br>\n";
    print "Você pode ter quebras de linhas em uma string.<br>";
    print 'Uma string pode usar "aspas-duplas". Isso é muito legal!<br>';
    print "Ainda pode-se usar aspas simples dessa forma It\'s cool!<br>";
    ?>
    <br>
    <br>
    <br>
    <?php
    echo "teste<br>";
    echo "Olá, Mundo<br>\n";
    echo "Isso abrange várias linhas. As novas linhas serão saída também<br>";
    echo "Você pode ter quebras de linhas em uma string.<br>";
    echo 'Uma string pode usar "aspas-duplas". Isso é muito legal!<br>';
    echo "Ainda pode-se usar aspas simples dessa forma It\'s cool!<br>";
    ?>
    <BR>
    <BR>
    <BR>
    <?php
        echo " <h2 align='center'> O meu programa está ecoando corretamente no meu servidor PHP!</h2>"
    ?>
</body>
</html>