<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $n1 = 1;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n1 * $num2. "<br>";
    print('<br>');

        $n2 = 2;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n2 * $num2. "<br>";
    print('<br>');

        $n3 = 3;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n3 * $num2. "<br>";
    print('<br>');

        $n4 = 4;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n4* $num2. "<br>";
    print('<br>');

        $n5 = 5;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n5 * $num2. "<br>";
    print('<br>');

        $n6 = 6;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n6 * $num2. "<br>";
    print('<br>');

        $n7 = 7;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n7 * $num2. "<br>";
    print('<br>');
    
        $n8 = 8;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n8 * $num2. "<br>";
    print('<br>');

        $n9 = 9;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n9 * $num2. "<br>";
    print('<br>');

        $n10 = 10;
    for ($num2 = 0; $num2 <= 10; $num2++)
        print "$n1 X $num2 = ". $n10 * $num2. "<br>";
    print('<br>');
    ?>
</body>
</html>